import React from 'react';

const ResultsTable = ({ results }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Position</th>
          <th>Company</th>
          <th>Location</th>
          <th>Match Percentage</th>
        </tr>
      </thead>
      <tbody>
        {results.map((job, index) => (
          <tr key={index}>
            <td>{job.Position}</td>
            <td>{job.Company}</td>
            <td>{job.Location}</td>
            <td>{job['Match Percentage'].toFixed(2)}%</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ResultsTable;
