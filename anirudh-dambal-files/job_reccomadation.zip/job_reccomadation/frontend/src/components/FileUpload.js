import React from 'react';

const FileUpload = ({ onFileChange }) => {
  return (
    <div>
      <label htmlFor="resumeFile">Upload Resume:</label>
      <input 
        type="file" 
        id="resumeFile" 
        onChange={onFileChange} 
        accept=".doc,.docx,.pdf" 
      />
    </div>
  );
};

export default FileUpload;
