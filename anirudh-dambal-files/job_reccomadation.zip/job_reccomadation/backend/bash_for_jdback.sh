pip install flask pandas torch transformers scikit-learn pyresparser python-docx flask-socketio

